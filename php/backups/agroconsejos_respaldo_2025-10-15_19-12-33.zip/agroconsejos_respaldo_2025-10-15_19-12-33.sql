-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: agroconsejos
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bitacora_accesos`
--

DROP TABLE IF EXISTS `bitacora_accesos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bitacora_accesos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `fecha_entrada` datetime DEFAULT current_timestamp(),
  `fecha_salida` datetime DEFAULT NULL,
  `tiempo_sesion` int(11) DEFAULT 0,
  `activo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `bitacora_accesos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bitacora_accesos`
--

LOCK TABLES `bitacora_accesos` WRITE;
/*!40000 ALTER TABLE `bitacora_accesos` DISABLE KEYS */;
INSERT INTO `bitacora_accesos` (`id`, `usuario_id`, `fecha_entrada`, `fecha_salida`, `tiempo_sesion`, `activo`) VALUES (1,2,'2025-10-11 16:41:25','2025-10-11 16:41:55',30,0),(2,5,'2025-10-11 17:25:07','2025-10-11 17:28:41',214,0),(3,2,'2025-10-11 17:28:53','2025-10-11 17:29:54',61,0),(4,5,'2025-10-11 17:30:10','2025-10-11 17:30:31',21,0),(5,5,'2025-10-12 01:29:00','2025-10-12 02:38:46',4186,0),(6,2,'2025-10-13 08:36:50','2025-10-13 08:38:33',103,0),(7,6,'2025-10-13 08:45:07','2025-10-13 08:49:39',272,0),(8,5,'2025-10-13 08:49:59','2025-10-13 08:55:30',331,0),(9,5,'2025-10-13 11:46:56',NULL,0,1),(10,5,'2025-10-15 11:11:43',NULL,0,1);
/*!40000 ALTER TABLE `bitacora_accesos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_entradas`
--

DROP TABLE IF EXISTS `blog_entradas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_entradas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `titulo` varchar(200) NOT NULL,
  `contenido` text NOT NULL,
  `fecha_publicacion` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `blog_entradas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_entradas`
--

LOCK TABLES `blog_entradas` WRITE;
/*!40000 ALTER TABLE `blog_entradas` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_entradas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reseteo_contrasenas`
--

DROP TABLE IF EXISTS `reseteo_contrasenas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reseteo_contrasenas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `codigo` varchar(6) NOT NULL,
  `fecha_creacion` datetime DEFAULT current_timestamp(),
  `expiracion` datetime NOT NULL,
  `utilizado` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `reseteo_contrasenas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reseteo_contrasenas`
--

LOCK TABLES `reseteo_contrasenas` WRITE;
/*!40000 ALTER TABLE `reseteo_contrasenas` DISABLE KEYS */;
INSERT INTO `reseteo_contrasenas` (`id`, `usuario_id`, `codigo`, `fecha_creacion`, `expiracion`, `utilizado`) VALUES (4,2,'972375','2025-10-13 08:55:38','2025-10-13 17:00:38',0);
/*!40000 ALTER TABLE `reseteo_contrasenas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `correo` varchar(150) NOT NULL,
  `telefono` varchar(10) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `rol` enum('administrador','usuario') DEFAULT 'usuario',
  `activo` tinyint(1) DEFAULT 1,
  `fecha_registro` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` (`id`, `nombre`, `correo`, `telefono`, `contrasena`, `rol`, `activo`, `fecha_registro`) VALUES (2,'Diego Cuevas Ochoa','diecuevas16@outlook.com','4444249395','VlNvOTF5WXVTb0xCOXlIeTMvcW9Gdz09Ojq99Ym2AjyT4p6tySWDbzJf','usuario',1,'2025-10-11 16:41:05'),(5,'Administrador Principal','admin@agroconsejos.com','1234567890','Z25JbjhWVTFDWHpNcVpaa3ZRK1BzUT09Ojpj1VCShtBvn8kDWoXA34Nl','administrador',1,'2025-10-11 17:24:40'),(6,'Eva Arleth Salas','salasbeltran05@gmail.com','4444516967','c2puT1gycUFsclpJcmpidW05OFRjdz09OjqCRKJwxyuSmhLdd3sI8/NE','usuario',1,'2025-10-13 08:44:17');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `variables_agricolas`
--

DROP TABLE IF EXISTS `variables_agricolas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variables_agricolas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `temperatura` decimal(5,2) DEFAULT NULL,
  `humedad` decimal(5,2) DEFAULT NULL,
  `radiacion` decimal(5,2) DEFAULT NULL,
  `precipitacion` decimal(5,2) DEFAULT NULL,
  `ph_suelo` decimal(4,2) DEFAULT NULL,
  `fertilidad` varchar(50) DEFAULT NULL,
  `nutrientes` text DEFAULT NULL,
  `calidad_agua` varchar(50) DEFAULT NULL,
  `fecha_registro` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `variables_agricolas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `variables_agricolas`
--

LOCK TABLES `variables_agricolas` WRITE;
/*!40000 ALTER TABLE `variables_agricolas` DISABLE KEYS */;
/*!40000 ALTER TABLE `variables_agricolas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'agroconsejos'
--

--
-- Dumping routines for database 'agroconsejos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-15 11:12:33
